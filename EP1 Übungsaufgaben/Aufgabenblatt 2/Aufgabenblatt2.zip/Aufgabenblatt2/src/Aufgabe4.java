/*
    Aufgabe 4) "Guessing Game" und Verwendung von Methoden
*/

import java.util.Scanner;

public class Aufgabe4 {

    //TODO: Implementieren Sie hier Ihre Methoden

    public static void main(String[] args) {

        //TODO: Implementieren Sie hier Ihr "GuessingGame"
    }
}
