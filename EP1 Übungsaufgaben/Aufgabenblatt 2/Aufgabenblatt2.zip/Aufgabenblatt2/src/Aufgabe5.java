/*
    Aufgabe 5) Designaufgabe
*/
public class Aufgabe5 {

    public static void main(String[] args) {

        //TODO: Implementieren Sie hier Ihre Lösung für die DESIGNAUFGABE
    }
}
