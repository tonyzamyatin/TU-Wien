/*
    Aufgabe 1) Schleifen - geometrische Formen und Muster (optische Täuschung)
*/

import codedraw.CodeDraw;
import codedraw.Palette;

public class Aufgabe1 {

    public static void main(String[] args) {

        //TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }
}
