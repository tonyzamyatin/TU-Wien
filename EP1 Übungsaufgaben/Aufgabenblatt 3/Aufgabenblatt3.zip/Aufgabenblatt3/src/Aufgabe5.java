/*
    Aufgabe 5) Kreismuster => Rekursiv vs. Iterativ
*/

import codedraw.CodeDraw;

import java.awt.*;

public class Aufgabe5 {

    private static void drawCirclePatternRecursively(CodeDraw myDrawObj, int x, int y, int r) {
        // TODO: Implementieren Sie hier Ihre Lösung für die Methode
    }

    private static void drawCirclePatternIteratively(CodeDraw myDrawObj, int maxRadius) {
        // TODO: Implementieren Sie hier Ihre Lösung für die Methode
    }

    public static void main(String[] args) {
        // TODO: Implementieren Sie hier Ihre Lösung für die Angabe
    }
}


