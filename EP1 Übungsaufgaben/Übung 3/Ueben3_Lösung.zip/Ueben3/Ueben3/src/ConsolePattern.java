public class ConsolePattern {

    public static void main(String[] args) {

        System.out.println("Größe des Quadrats:");

    }
}
