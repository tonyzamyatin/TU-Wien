public class Passwords {
    public static void main(String[] args) {

        System.out.println("Geben Sie ein Passwort ein:");

    }
}
